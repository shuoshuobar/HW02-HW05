tricked you again! go up a directory and look for the HIDDEN FILE using ls.
