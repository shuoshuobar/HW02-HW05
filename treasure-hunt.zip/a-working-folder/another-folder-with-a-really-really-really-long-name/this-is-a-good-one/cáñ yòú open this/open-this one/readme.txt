just kidding, go up a directory and open the "dont open me" one
